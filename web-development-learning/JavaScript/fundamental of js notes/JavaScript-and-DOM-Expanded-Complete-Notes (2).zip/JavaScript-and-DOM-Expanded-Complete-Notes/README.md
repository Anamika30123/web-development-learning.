# JavaScript and DOM — Expanded Complete Notes

This learning pack keeps core JavaScript and browser DOM in separate files.

## Files
1. `JavaScript-Complete-Notes.md` — core language from beginner to advanced, including variables, data types, operators, strings, arrays, objects, functions, scope, hoisting, closures, `this`, execution context, call stack, event loop, Promises, async/await, prototypes, classes, RegExp, Date, Math, Map/Set, iterators, generators, Proxy, memory and browser/runtime concepts.
2. `DOM-Complete-Notes.md` — browser DOM including window/document, node types, selectors, content, attributes, styles, classList, traversal, dataset, forms, element creation/insertion/removal/replacement, events, listener options/removal, propagation, observers, accessibility and performance.
3. `STUDY-ORDER.md` — suggested study sequence.

## Important note
JavaScript and the browser platform are extensive and continue to evolve. These notes aim to be a broad, practical beginner-to-advanced learning and interview reference, not a literal catalogue of every language feature, browser API or specification detail. Check MDN and compatibility tables when using a newer API in a real project.

## Study method
- Read one concept at a time.
- Type every example yourself.
- Predict the output before running it.
- Explain the reason in your own words.
- Practise building small projects after each section.
