# JavaScript and DOM — Suggested Study Order

## Part 1: JavaScript
1. Introduction, variables and data types
2. Type conversion, operators and conditions
3. Loops, strings, arrays and objects
4. Functions, callbacks and higher-order functions
5. Scope, hoisting, TDZ and closures
6. `this`, call, apply and bind
7. Execution context, call stack and event loop
8. Promises, async/await and Fetch
9. Prototypes, classes, errors and modules
10. Number, Math, Date, RegExp and Intl
11. Map, Set, Symbols, iterators and generators
12. Copying, descriptors, getters/setters, Proxy and Reflect
13. Memory, performance and runtime/browser APIs

## Part 2: DOM
1. Window, document, DOM tree and node types
2. Selectors and HTMLCollection vs NodeList
3. Text, HTML, attributes and dataset
4. Style, classList and DOM traversal
5. Create, insert, remove, replace and clone elements
6. Forms, input values and validation
7. Events, event object and listener options
8. Removing listeners, bubbling, capturing and delegation
9. DOMContentLoaded, storage and browser APIs
10. MutationObserver, IntersectionObserver and ResizeObserver
11. Accessibility and DOM performance

## Practice rule
For every topic:
- Read the note.
- Type the example yourself.
- Change one value and predict the output.
- Explain the concept aloud without reading.
- Build a small example using the concept.
