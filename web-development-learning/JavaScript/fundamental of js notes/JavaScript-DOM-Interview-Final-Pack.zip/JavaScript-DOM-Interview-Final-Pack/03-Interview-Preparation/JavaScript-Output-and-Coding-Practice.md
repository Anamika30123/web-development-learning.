# JavaScript Output-Based and Coding Interview Practice

Try each question before reading the answer. Run examples in your browser console or Node.js.

## Part A — Predict the Output

### 1. String plus number
```javascript
console.log("5" + 2);
console.log("5" - 2);
```
Answer: `52`, then `3`. `+` concatenates with a string; `-` converts to numbers.

### 2. Equality
```javascript
console.log(5 == "5");
console.log(5 === "5");
```
Answer: `true`, then `false`.

### 3. Truthy values
```javascript
console.log(Boolean(""));
console.log(Boolean("false"));
console.log(Boolean([]));
console.log(Boolean({}));
```
Answer: `false`, `true`, `true`, `true`.

### 4. var hoisting
```javascript
console.log(score);
var score = 10;
```
Answer: `undefined`. The `var` binding is initialized to `undefined` during setup.

### 5. Temporal dead zone
```javascript
console.log(score);
let score = 10;
```
Answer: `ReferenceError`, because the binding has not been initialized.

### 6. Prefix and postfix
```javascript
let x = 4;
console.log(x++);
console.log(++x);
```
Answer: `4`, then `6`.

### 7. slice
```javascript
const values = [10, 20, 30];
const part = values.slice(1);
console.log(part);
console.log(values);
```
Answer: `[20, 30]`, then `[10, 20, 30]`.

### 8. splice
```javascript
const values = ["a", "b", "c"];
values.splice(1, 1);
console.log(values);
```
Answer: `["a", "c"]`. `splice()` mutates the original.

### 9. map
```javascript
console.log([1, 2, 3].map(n => n * 3));
```
Answer: `[3, 6, 9]`.

### 10. filter
```javascript
console.log([1, 2, 3, 4].filter(n => n > 2));
```
Answer: `[3, 4]`.

### 11. typeof
```javascript
console.log(typeof null);
console.log(typeof []);
console.log(typeof NaN);
```
Answer: `"object"`, `"object"`, `"number"`.

### 12. Closure
```javascript
function outer() {
  let count = 0;
  return function () {
    count++;
    return count;
  };
}
const next = outer();
console.log(next());
console.log(next());
```
Answer: `1`, then `2`. The inner function retains access to `count`.

### 13. Block scope
```javascript
if (true) {
  var a = 1;
  let b = 2;
}
console.log(a);
console.log(typeof b);
```
Answer: `1`, then `"undefined"`.

### 14. Promise and timer order
```javascript
console.log("A");
setTimeout(() => console.log("B"), 0);
Promise.resolve().then(() => console.log("C"));
console.log("D");
```
Answer:
```text
A
D
C
B
```
Synchronous code first, then Promise microtasks, then timer task.

### 15. Async function
```javascript
async function run() {
  return 7;
}
run().then(value => console.log(value));
```
Answer: `7`. An async function returns a Promise.

### 16. this in a method
```javascript
const user = {
  name: "Maya",
  show() { console.log(this.name); }
};
user.show();
```
Answer: `Maya`.

### 17. Object reference
```javascript
const a = { score: 10 };
const b = a;
b.score = 20;
console.log(a.score);
```
Answer: `20`. Both variables reference the same object.

### 18. Shallow copy
```javascript
const original = [{ value: 1 }];
const copy = [...original];
copy[0].value = 9;
console.log(original[0].value);
```
Answer: `9`. The nested object is shared.

### 19. Listener removal
```javascript
const handler = () => console.log("Hi");
button.addEventListener("click", handler);
button.removeEventListener("click", handler);
```
Answer: The listener is removed because the same function reference is used.

### 20. OR vs nullish coalescing
```javascript
console.log(0 || 10);
console.log(0 ?? 10);
```
Answer: `10`, then `0`.

---

## Part B — Coding Questions with Solutions

### 1. Reverse a string
```javascript
function reverseString(str) {
  return str.split("").reverse().join("");
}
console.log(reverseString("hello")); // "olleh"
```

### 2. Check palindrome
```javascript
function isPalindrome(str) {
  const clean = str.toLowerCase().replace(/[^a-z0-9]/g, "");
  return clean === clean.split("").reverse().join("");
}
console.log(isPalindrome("Madam")); // true
```

### 3. Find largest number
```javascript
function largest(numbers) {
  if (numbers.length === 0) return undefined;
  return Math.max(...numbers);
}
console.log(largest([4, 9, 2, 7])); // 9
```

### 4. Sum an array
```javascript
const sum = numbers => numbers.reduce((total, n) => total + n, 0);
console.log(sum([1, 2, 3, 4])); // 10
```

### 5. Remove duplicates
```javascript
const unique = values => [...new Set(values)];
console.log(unique([1, 2, 2, 3, 1])); // [1, 2, 3]
```

### 6. Character frequency
```javascript
function charFrequency(str) {
  const result = {};
  for (const char of str) {
    result[char] = (result[char] || 0) + 1;
  }
  return result;
}
console.log(charFrequency("hello"));
```

### 7. Filter even numbers
```javascript
const evens = numbers => numbers.filter(n => n % 2 === 0);
console.log(evens([1, 2, 3, 4, 5, 6])); // [2, 4, 6]
```

### 8. Square numbers
```javascript
const squares = numbers => numbers.map(n => n * n);
console.log(squares([2, 3, 4])); // [4, 9, 16]
```

### 9. Second-largest distinct number
```javascript
function secondLargest(numbers) {
  const sorted = [...new Set(numbers)].sort((a, b) => b - a);
  return sorted.length < 2 ? undefined : sorted[1];
}
console.log(secondLargest([10, 5, 8, 10, 3])); // 8
```

### 10. FizzBuzz
```javascript
function fizzBuzz(n) {
  for (let i = 1; i <= n; i++) {
    if (i % 15 === 0) console.log("FizzBuzz");
    else if (i % 3 === 0) console.log("Fizz");
    else if (i % 5 === 0) console.log("Buzz");
    else console.log(i);
  }
}
fizzBuzz(15);
```

### 11. Counter using closure
```javascript
function createCounter() {
  let count = 0;
  return () => ++count;
}
const counter = createCounter();
console.log(counter()); // 1
console.log(counter()); // 2
```

### 12. Flatten one level
```javascript
const nested = [1, [2, 3], [4, 5]];
console.log(nested.flat()); // [1, 2, 3, 4, 5]
```

### 13. Group objects by a property
```javascript
function groupBy(items, key) {
  return items.reduce((groups, item) => {
    const name = item[key];
    (groups[name] ??= []).push(item);
    return groups;
  }, {});
}
const people = [
  { name: "A", team: "red" },
  { name: "B", team: "blue" },
  { name: "C", team: "red" }
];
console.log(groupBy(people, "team"));
```

### 14. Debounce
```javascript
function debounce(fn, delay) {
  let timerId;
  return function (...args) {
    clearTimeout(timerId);
    timerId = setTimeout(() => fn.apply(this, args), delay);
  };
}
```
Use case: wait until a user pauses typing before searching.

### 15. Throttle
```javascript
function throttle(fn, delay) {
  let lastRun = 0;
  return function (...args) {
    const now = Date.now();
    if (now - lastRun >= delay) {
      lastRun = now;
      fn.apply(this, args);
    }
  };
}
```
This is a simple leading throttle. Use case: limit frequent scroll handler execution.

### 16. Fetch and handle HTTP errors
```javascript
async function getUsers() {
  const response = await fetch("https://jsonplaceholder.typicode.com/users");
  if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
  return response.json();
}
getUsers().then(console.log).catch(console.error);
```

### 17. Create a DOM element
```javascript
const list = document.querySelector("#list");
const item = document.createElement("li");
item.textContent = "Learn JavaScript";
list.append(item);
```

### 18. Event delegation
```javascript
const list = document.querySelector("#list");
list.addEventListener("click", event => {
  const item = event.target.closest("li");
  if (item && list.contains(item)) {
    console.log("Selected:", item.textContent);
  }
});
```

### 19. First non-repeating character
```javascript
function firstUniqueChar(str) {
  const counts = new Map();
  for (const char of str) {
    counts.set(char, (counts.get(char) || 0) + 1);
  }
  for (const char of str) {
    if (counts.get(char) === 1) return char;
  }
  return null;
}
console.log(firstUniqueChar("aabbcdd")); // "c"
```

### 20. Check anagrams
```javascript
function areAnagrams(a, b) {
  const normalize = str =>
    str.toLowerCase().replace(/\s/g, "").split("").sort().join("");
  return normalize(a) === normalize(b);
}
console.log(areAnagrams("listen", "silent")); // true
```

## Part C — Additional Questions to Solve Yourself
1. Find the smallest number in an array.
2. Find the missing number in a sequence.
3. Count vowels in a string.
4. Capitalize the first letter of every word.
5. Count frequency of numbers in an array.
6. Merge arrays and remove duplicates.
7. Move all zeros to the end.
8. Find common elements in two arrays.
9. Sort an array without `sort()`.
10. Find the longest word in a sentence.
11. Check whether two arrays are equal.
12. Create a function that runs only once.
13. Implement custom `map()`, `filter()` and `reduce()`.
14. Explain the `var` loop with `setTimeout` output puzzle.
15. Build a to-do list with add/delete/complete.
16. Build a search box using debounce.
17. Fetch API data and show loading, success and error states.
18. Create a modal with open and close events.
