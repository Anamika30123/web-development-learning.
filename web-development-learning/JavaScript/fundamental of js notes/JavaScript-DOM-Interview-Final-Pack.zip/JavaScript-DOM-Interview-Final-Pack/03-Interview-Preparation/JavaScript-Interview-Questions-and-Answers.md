# JavaScript Interview Questions and Answers
## Beginner to Advanced — Fresher and Junior Developer Preparation

Answers use simple interview-ready language with examples. This is a broad curated preparation bank, not a guarantee that every question is asked by every company.

## Contents
1. Fundamentals
2. Variables, scope and hoisting
3. Data types and coercion
4. Operators and conditions
5. Strings
6. Arrays
7. Objects and collections
8. Functions
9. Closures and `this`
10. Execution context, call stack and event loop
11. Promises and asynchronous JavaScript
12. DOM and browser events
13. Modern JavaScript
14. Prototypes, classes and OOP
15. Errors, debugging and storage
16. Fetch, APIs and browser security
17. Performance patterns
18. Modules and tooling

---

# 1. JavaScript Fundamentals

### Q1. What is JavaScript?
JavaScript is a high-level, dynamic programming language used to build interactive web pages and applications. It runs in browsers and in other environments such as Node.js.

### Q2. Is JavaScript the same as Java?
No. They are different languages. Java is statically typed and class-based. JavaScript is dynamically typed and prototype-based, although it also supports class syntax.

### Q3. Where does JavaScript run?
It runs in JavaScript engines such as V8, SpiderMonkey and JavaScriptCore. Browsers and runtimes such as Node.js provide additional environment APIs.

### Q4. What is ECMAScript?
ECMAScript is the language specification that defines the core JavaScript standard. JavaScript engines implement this specification.

### Q5. Is JavaScript interpreted or compiled?
Modern engines use a combination of parsing, interpretation and just-in-time compilation/optimization. Calling it only interpreted is an oversimplification.

### Q6. Is JavaScript single-threaded?
JavaScript code in a given execution context normally runs one task at a time on its main thread. The browser or runtime can perform other work in the background and schedule callbacks through the event loop.

### Q7. What is the difference between JavaScript and the DOM?
JavaScript is a programming language. The DOM is a browser-provided object model representing an HTML document. JavaScript uses DOM APIs to access and change a page.

### Q8. What is Node.js?
Node.js is a JavaScript runtime built on V8 that allows JavaScript to run outside a browser, with APIs for networking, files and server-side development.

### Q9. What are comments?
Comments explain code and are ignored during execution.
```javascript
// Single-line comment
/* Multi-line comment */
```

### Q10. What is strict mode?
`"use strict";` enables stricter language rules and catches some mistakes, such as accidental assignment to undeclared variables. Modules and class bodies are strict by default.

# 2. Variables, Scope and Hoisting

### Q11. What is a variable?
A variable is a named binding used to refer to a value.
```javascript
let age = 22;
```

### Q12. Difference between `var`, `let` and `const`?
`var` is function-scoped (or script-global), can be redeclared and reassigned. `let` is block-scoped and can be reassigned but not redeclared in the same scope. `const` is block-scoped, must be initialized and cannot be reassigned. Prefer `const` unless reassignment is needed; avoid `var` in modern code.

### Q13. Explain declaration, initialization and reassignment.
Declaration creates a binding. Initialization gives it its first value. Reassignment changes the existing value.
```javascript
let score;      // declaration
score = 10;     // initialization
score = 20;     // reassignment
```

### Q14. What is scope?
Scope determines where a variable or function can be accessed. Common types are global, function and block scope.

### Q15. What is block scope?
`let` and `const` declared inside a block `{}` are accessible only within that block.
```javascript
if (true) {
  let message = "Hi";
}
// message is not available here
```

### Q16. What is function scope?
A `var` declared inside a function is accessible throughout that function, but not outside it.

### Q17. What is global scope?
It is the outermost scope available to the relevant script. Top-level declarations in ES modules do not become properties of `window`.

### Q18. What is hoisting?
Hoisting is an informal term for declaration processing during scope setup before normal statements execute. Code is not literally moved. `var` is initialized to `undefined`; `let` and `const` are uninitialized until their declaration is evaluated; function declarations can generally be called before their position.

### Q19. What is the Temporal Dead Zone (TDZ)?
The period from entering a scope until a `let` or `const` binding is initialized. Accessing it during this period throws a `ReferenceError`.

### Q20. Are `let` and `const` hoisted?
Their bindings are created during scope setup, but cannot be accessed before initialization. That is why early access throws a `ReferenceError`.

### Q21. Function declaration vs function expression?
A function declaration defines a function and can generally be called before its position. A function expression creates a function value in an expression, often assigned to a variable.
```javascript
function greet() {}
const sayHi = function () {};
```

### Q22. What is variable shadowing?
An inner-scope variable uses the same name as an outer-scope variable, hiding the outer binding within the inner scope.

### Q23. Difference between `undefined` and an undeclared variable?
A declared variable without a value is `undefined`. Referencing a name with no accessible declaration generally throws a `ReferenceError`.

# 3. Data Types and Type Conversion

### Q24. What are JavaScript's primitive types?
`string`, `number`, `bigint`, `boolean`, `undefined`, `symbol` and `null`.

### Q25. What are reference types?
Objects are reference values. Arrays, functions and dates are objects. Assigning an object copies its reference, not the object itself.

### Q26. What does `typeof` do?
It returns a string describing a value's type.
```javascript
typeof "hi"; // "string"
typeof 42;   // "number"
typeof true; // "boolean"
typeof 10n;  // "bigint"
```

### Q27. Why does `typeof null` return `"object"`?
It is a historical JavaScript quirk. Use `value === null` to test for null.

### Q28. Difference between `null` and `undefined`?
`undefined` commonly means a value has not been assigned or is missing. `null` is an intentional absence of a value.

### Q29. What is `NaN`?
It means “Not a Number” and represents an invalid numeric result. Its type is `"number"`. Use `Number.isNaN(value)` to test it.

### Q30. What is type coercion?
It is automatic or explicit conversion between types. For example, `"5" + 2` results in `"52"` because `+` concatenates strings.

### Q31. Difference between `==` and `===`?
`==` allows type coercion before comparison. `===` compares without converting types. Prefer `===` in most cases.

### Q32. What is explicit type conversion?
It is conversion performed intentionally using `Number()`, `String()` or `Boolean()`.

### Q33. What are truthy and falsy values?
Truthy values behave like true in conditions; falsy values behave like false. Falsy values are `false`, `0`, `-0`, `0n`, `""`, `null`, `undefined` and `NaN`. Empty arrays and objects are truthy.

### Q34. What is BigInt?
BigInt represents integers beyond Number's safe integer range. A BigInt literal ends in `n`, such as `123n`. Do not mix BigInt and Number in arithmetic without conversion.

### Q35. What is Symbol?
A Symbol is a unique primitive value, often used as a unique object property key.

### Q36. Difference between `isNaN()` and `Number.isNaN()`?
Global `isNaN()` converts its argument to a number before testing. `Number.isNaN()` returns true only for the actual numeric `NaN` value.

# 4. Operators and Conditions

### Q37. Name arithmetic operators.
`+`, `-`, `*`, `/`, `%` (remainder) and `**` (exponentiation).

### Q38. Difference between `++x` and `x++`?
Prefix increment updates first and evaluates to the new value. Postfix evaluates to the old value and then increments.

### Q39. What is the ternary operator?
A short conditional expression: `condition ? valueIfTrue : valueIfFalse`.

### Q40. Difference between `||` and `??`?
`||` uses the right side if the left side is falsy. `??` uses the right side only if the left side is `null` or `undefined`.
```javascript
0 || 10; // 10
0 ?? 10; // 0
```

### Q41. What is optional chaining?
`?.` safely accesses a property or method when the value before it is not nullish; it returns `undefined` instead of throwing for that access.

### Q42. Difference between `if...else` and `switch`?
`if...else` handles general conditions and ranges. `switch` compares one expression against multiple fixed case values.

### Q43. What do `break` and `continue` do?
`break` exits a loop or switch. `continue` skips the rest of the current loop iteration.

### Q44. Difference between `for`, `while` and `do...while`?
`for` groups initialization, condition and update. `while` checks before each iteration. `do...while` checks after the body, so it always runs at least once.

### Q45. Difference between `for...of` and `for...in`?
`for...of` iterates values from an iterable such as an array. `for...in` iterates enumerable property keys, commonly on objects.

# 5. Strings

### Q46. What is a string?
A string is a sequence of text characters, written with single quotes, double quotes or backticks. Strings are immutable.

### Q47. What are template literals?
Strings written with backticks. They support interpolation with `${}` and multiline text.
```javascript
const name = "Anu";
console.log(`Hello, ${name}`);
```

### Q48. How do you find string length?
Use `.length`, for example `"JavaScript".length`.

### Q49. Name common string methods.
`toUpperCase()`, `toLowerCase()`, `trim()`, `includes()`, `indexOf()`, `slice()`, `replace()`, `replaceAll()`, `split()` and `startsWith()`.

### Q50. Difference between `slice()` and `substring()`?
Both extract part of a string. `slice()` supports negative indexes. `substring()` treats negative indexes as zero and swaps its arguments if start is greater than end.

### Q51. Does `replace()` replace all occurrences?
A string search argument replaces the first occurrence. Use `replaceAll()` or a global regular expression to replace all occurrences.

# 6. Arrays

### Q52. What is an array?
An ordered collection of values. Indexing starts at zero.

### Q53. How do you add/remove array elements?
`push()` adds at the end; `pop()` removes from the end; `unshift()` adds at the beginning; `shift()` removes from the beginning.

### Q54. Difference between `slice()` and `splice()`?
`slice()` returns a shallow copy of a range without changing the original. `splice()` changes the original by removing, inserting or replacing elements.

### Q55. What does `map()` do?
Creates a new array by transforming every element.
```javascript
[1, 2, 3].map(n => n * 2); // [2, 4, 6]
```

### Q56. What does `filter()` do?
Creates a new array containing elements that pass a test.
```javascript
[1, 2, 3, 4].filter(n => n % 2 === 0); // [2, 4]
```

### Q57. What does `reduce()` do?
Combines array elements into one accumulated result.
```javascript
[1, 2, 3].reduce((sum, n) => sum + n, 0); // 6
```

### Q58. Difference between `map()` and `forEach()`?
`map()` returns a new array of callback results. `forEach()` runs a callback for each element and returns `undefined`.

### Q59. What do `find()` and `findIndex()` do?
`find()` returns the first matching element or `undefined`. `findIndex()` returns its index or `-1`.

### Q60. Difference between `some()` and `every()`?
`some()` is true if at least one item passes a test. `every()` is true only if all items pass.

### Q61. Difference between `includes()` and `indexOf()`?
`includes()` returns true/false. `indexOf()` returns the first matching index or `-1`.

### Q62. Does `sort()` modify the original array?
Yes. It sorts in place. For numeric sorting use a comparator: `[10, 2].sort((a,b) => a-b)`.

### Q63. What is array destructuring?
Extracting values into variables: `const [first, second] = ["red", "blue"];`.

### Q64. What is spread syntax with arrays?
`...` expands iterable values and is commonly used to copy or combine arrays. It makes a shallow copy.

### Q65. What is a shallow copy?
It copies the outer array/object but keeps references to nested objects. Mutating a shared nested object can affect both copies.

### Q66. How do you remove duplicate primitive values?
Use `const unique = [...new Set(values)]`.

# 7. Objects and Collections

### Q67. What is an object?
A collection of properties represented as key-value pairs.

### Q68. Difference between dot and bracket notation?
Dot notation uses a fixed property name (`user.name`). Bracket notation accepts an expression (`user[key]`) and supports keys containing spaces or special characters.

### Q69. How do you add, update and delete object properties?
`user.city = "Pune"` adds; `user.age = 23` updates; `delete user.city` removes.

### Q70. What do `Object.keys()`, `Object.values()` and `Object.entries()` return?
Arrays of an object's own enumerable string-keyed property names, values, and `[key, value]` pairs.

### Q71. What is object destructuring?
Extracting properties into variables: `const { name, age } = user;`.

### Q72. What is object spread?
`{ ...user, age: 24 }` copies enumerable own properties into a new object. It is shallow.

### Q73. What is an object reference?
Assigning an object to another variable copies the reference. Both variables can refer to the same object.

### Q74. Difference between `Object.freeze()` and `Object.seal()`?
`freeze()` prevents adding, deleting and changing own properties. `seal()` prevents adding or deleting, but existing writable properties can still change. Both are shallow.

### Q75. What is JSON?
A text data format. `JSON.stringify()` converts a compatible value to JSON text; `JSON.parse()` parses JSON text into a JavaScript value.

### Q76. Difference between `Map` and object?
`Map` supports keys of any type, preserves insertion order and has `.size`. Object keys are strings or Symbols (with prototype behaviour unless created without a prototype).

### Q77. What are `Set`, `WeakMap` and `WeakSet`?
`Set` stores unique values. `WeakMap` stores values against weakly held object keys. `WeakSet` weakly stores objects. Weak collections are not enumerable.

# 8. Functions

### Q78. What is a function?
A reusable block of code that can accept inputs, perform work and optionally return a value.

### Q79. Difference between parameters and arguments?
Parameters are names in the function definition. Arguments are actual values passed when calling it.

### Q80. Difference between `return` and `console.log()`?
`return` sends a value to the caller and ends the function. `console.log()` displays a value; it does not automatically return it.

### Q81. What is an arrow function?
A concise function syntax, e.g. `const add = (a,b) => a+b;`. Arrow functions do not have their own `this`, `arguments` or constructor behaviour.

### Q82. Regular function vs arrow function?
Regular functions get `this` from how they are called and can be constructors when used with `new`. Arrow functions inherit `this` lexically and cannot be constructors.

### Q83. What is a callback?
A function passed to another function so it can be called during that function's work or later.

### Q84. What is a higher-order function?
A function that accepts another function, returns a function, or both. `map()` and `filter()` are examples.

### Q85. What is a pure function?
A function that returns the same result for the same inputs and has no observable side effects.

### Q86. What is recursion?
A function calling itself. It needs a base case to stop.
```javascript
function factorial(n) {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
}
```

### Q87. What are default parameters?
Fallback values used when an argument is missing or `undefined`.

### Q88. What is a rest parameter?
`...` collects remaining function arguments into an array: `function sum(...nums) {}`.

### Q89. What is an IIFE?
An Immediately Invoked Function Expression, called immediately after it is defined.
```javascript
(function () { console.log("Runs now"); })();
```

### Q90. What is currying?
Transforming a multi-argument function into a sequence of functions, each accepting fewer arguments: `const add = a => b => a + b;`.

# 9. Closures, Scope and `this`

### Q91. What is lexical scope?
Variable access is determined by where functions and blocks are written in the source code.

### Q92. What is a closure?
A closure is a function together with access to variables from its surrounding lexical scope, even after the outer function has finished.
```javascript
function makeCounter() {
  let count = 0;
  return () => ++count;
}
const counter = makeCounter();
counter(); // 1
counter(); // 2
```

### Q93. Where are closures useful?
Preserving state, private data, function factories, callbacks, event handlers and memoization.

### Q94. What is the scope chain?
JavaScript checks the current lexical scope for a variable, then outer scopes until it finds the binding or reaches the outermost scope.

### Q95. What does `this` mean?
For regular functions, `this` is mainly determined by how the function is called. In `obj.method()`, it is generally `obj`.

### Q96. How does `this` work in arrow functions?
An arrow function has no own `this`; it uses the surrounding lexical `this`.

### Q97. What are `call()`, `apply()` and `bind()`?
They control `this` for a regular function. `call(thisArg, a, b)` invokes with separate arguments; `apply(thisArg, [a,b])` invokes with an array-like list; `bind()` returns a new function with `this` (and optional leading arguments) fixed.

### Q98. What is memoization?
Caching a function's result so repeated calls with the same input can reuse it.

# 10. Execution Context, Call Stack and Event Loop

### Q99. What is an execution context?
The environment in which JavaScript code is evaluated, including information such as lexical environments and the current `this` binding.

### Q100. What are memory creation and code execution phases?
A simplified teaching model: during setup, bindings and function declarations are prepared; then statements execute. Actual engine internals are more detailed.

### Q101. What is the call stack?
A LIFO structure that tracks active function calls. A call is pushed when a function starts and popped when it returns.

### Q102. What is stack overflow?
An error caused when the call stack limit is exceeded, often by uncontrolled or very deep recursion.

### Q103. What is the event loop?
It coordinates when queued callbacks can run after current synchronous work finishes. It allows runtimes to handle asynchronous operations without blocking the main call stack while waiting.

### Q104. Synchronous vs asynchronous code?
Synchronous statements run in sequence. Asynchronous operations complete later and notify JavaScript through callbacks, promises or events.

### Q105. What are tasks and microtasks?
Tasks include timer callbacks and many event callbacks. Microtasks include Promise reactions and `queueMicrotask()`. After a task's synchronous code finishes, the runtime generally drains microtasks before selecting another task.

### Q106. Why does a Promise `.then()` normally run before `setTimeout(..., 0)`?
Promise reactions are microtasks; timer callbacks are tasks. Microtasks are processed before the next task.

# 11. Promises and Asynchronous JavaScript

### Q107. What is asynchronous JavaScript?
It allows work such as network requests and timers to complete later without blocking the main JavaScript flow while waiting.

### Q108. What is callback hell?
Deeply nested callbacks that make code hard to read, maintain and handle errors. Promises and `async/await` help structure asynchronous code.

### Q109. What is a Promise?
An object representing the eventual success or failure of an asynchronous operation. States: pending, fulfilled or rejected.

### Q110. How do you create a Promise?
```javascript
const task = new Promise((resolve, reject) => {
  const success = true;
  if (success) resolve("Done");
  else reject(new Error("Failed"));
});
```

### Q111. What do `.then()`, `.catch()` and `.finally()` do?
`.then()` handles fulfillment and chains results; `.catch()` handles rejection; `.finally()` runs after settlement regardless of outcome.

### Q112. What is Promise chaining?
Returning a value or Promise from `.then()` passes its eventual value to the next `.then()`. Rejections can be handled with `.catch()`.

### Q113. What is `async/await`?
An `async` function always returns a Promise. `await` pauses that async function until the Promise settles, then returns its value or throws its rejection reason.

### Q114. How do you handle errors with async/await?
Use `try...catch` around awaited operations.
```javascript
async function load() {
  try {
    const response = await fetch("/api/data");
    if (!response.ok) throw new Error("Request failed");
    return await response.json();
  } catch (error) {
    console.error(error);
  }
}
```

### Q115. Difference between `Promise.all()` and `Promise.allSettled()`?
`Promise.all()` fulfills when all inputs fulfill and rejects when one rejects. `Promise.allSettled()` waits for every input to settle and reports each outcome.

### Q116. What does `Promise.race()` do?
It settles with the first input Promise that settles, whether fulfilled or rejected.

### Q117. What does `Promise.any()` do?
It fulfills with the first fulfilled input. If all reject, it rejects with an `AggregateError`.

### Q118. Does `setTimeout(fn, 0)` run immediately?
No. It schedules a task that runs after the delay threshold when the call stack and other queued work allow it.

### Q119. What is Fetch?
Fetch is an API for network requests. It returns a Promise resolving to a Response. HTTP statuses such as 404 do not automatically reject; check `response.ok`.

### Q120. How do you cancel a fetch?
Create an `AbortController`, pass `controller.signal` to fetch, and call `controller.abort()` to cancel.

# 12. DOM and Browser Events

### Q121. What is the DOM?
The Document Object Model is a tree-like object representation of an HTML document. JavaScript can use it to access and modify page content and structure.

### Q122. Difference between `window` and `document`?
`window` is the browser global object. `document` represents the current webpage.

### Q123. Difference between `console.log()` and `console.dir()`?
`console.log()` is general-purpose logging. `console.dir()` is useful for inspecting object properties. The display depends on developer tools.

### Q124. What is a node? Name common node types.
A node is an item in the DOM tree. Common types: document (9), element (1), text (3), comment (8).

### Q125. Difference between node and element?
An element is a node representing an HTML element. Text and comment nodes are nodes but are not elements.

### Q126. Difference between `querySelector()` and `querySelectorAll()`?
`querySelector()` returns the first matching element or `null`. `querySelectorAll()` returns a static NodeList of all matches.

### Q127. Difference between `innerText`, `textContent` and `innerHTML`?
`innerText` is rendered text; `textContent` is text from the node and descendants; `innerHTML` reads or sets markup inside an element. Avoid inserting untrusted data through `innerHTML`.

### Q128. How do you get and set an attribute?
Use `getAttribute("name")` to read, `setAttribute("name", "value")` to set, and `removeAttribute()` to remove.

### Q129. How do you change an element's style?
Select it and use `element.style.color = "red"`. CSS property names with hyphens use camelCase, e.g. `backgroundColor`.

### Q130. What is `classList`?
It provides `add()`, `remove()`, `toggle()` and `contains()` to manage an element's CSS classes.

### Q131. How do you create and insert an element?
Use `document.createElement()`, add content/attributes, then insert with `append()`, `prepend()`, `before()` or `after()`.

### Q132. Difference between `append()` and `prepend()`?
`append()` inserts at the end inside a parent; `prepend()` inserts at the beginning inside it.

### Q133. Difference between `append()` and `before()`?
`append()` inserts inside a parent. `before()` inserts as a sibling before the selected element.

### Q134. What is an event?
An action or occurrence in the browser, such as a click, key press, input change or form submission, that code can respond to.

### Q135. What is `addEventListener()`?
It registers a callback for an event on a target: `button.addEventListener("click", handleClick)`.

### Q136. Why prefer `addEventListener()` over inline `onclick`?
It separates JavaScript from HTML, supports multiple listeners and offers options such as capture and once.

### Q137. What is the event object?
An object passed to an event handler containing details such as `type`, `target`, `currentTarget`, keyboard data and pointer coordinates.

### Q138. Difference between `target` and `currentTarget`?
`target` is where the event originated. `currentTarget` is the element whose listener is executing.

### Q139. How do you remove an event listener?
Use the same event type and exact same callback function reference. Store the callback in a named function or variable:
```javascript
const handleClick = () => console.log("Clicked");
button.addEventListener("click", handleClick);
button.removeEventListener("click", handleClick);
```
A newly created arrow function with identical code is a different reference and will not remove the original.

### Q140. What is event bubbling?
The event travels from its target upward through ancestor elements.

### Q141. What is event capturing?
The event travels from outer ancestors down toward the target. Use `{ capture: true }` to register in the capture phase.

### Q142. What is event delegation?
Attach one listener to a parent and inspect `event.target` (often using `matches()` or `closest()`) to handle events from child elements. Useful for dynamic lists.

### Q143. Difference between `preventDefault()` and `stopPropagation()`?
`preventDefault()` prevents the browser's default action. `stopPropagation()` stops the event travelling further along the propagation path.

### Q144. What is `DOMContentLoaded`?
It fires after HTML parsing is complete and the DOM is ready. It does not wait for every image or subresource to finish loading.

### Q145. Difference between localStorage, sessionStorage and cookies?
`localStorage` persists until cleared. `sessionStorage` is scoped to a tab's page session. Cookies can be sent with matching HTTP requests and have attributes for expiry, path and security.

# 13. Modern JavaScript (ES6+)

### Q146. Name important ES6 features.
`let`/`const`, arrow functions, template literals, destructuring, default parameters, rest/spread, classes, modules, Promises, `Map` and `Set`.

### Q147. What is destructuring?
Syntax for extracting values from arrays or properties from objects into variables.

### Q148. Difference between rest and spread?
Both use `...`. Spread expands values in a new context; rest collects remaining values into an array or object.

### Q149. What are default parameters?
Fallback values used when an argument is missing or `undefined`.

### Q150. What are JavaScript modules?
Modules split code into files using `export` and `import`. They help organize reusable code and have their own scope.

### Q151. Named export vs default export?
A module can have multiple named exports imported by their names (or aliases), and one default export imported with a chosen local name.

### Q152. What is a generator?
A `function*` that can pause and resume using `yield`, returning an iterator.

### Q153. What is an iterator?
An object with a `next()` method that returns `{ value, done }`.

### Q154. What is a Proxy?
A wrapper that can intercept operations on an object, such as property reads, writes and function calls.

### Q155. What is nullish coalescing?
`??` uses the right operand only when the left is `null` or `undefined`.

### Q156. What is optional chaining?
`?.` safely accesses nested properties or calls when the value before it is nullish.

# 14. Prototypes, Classes and OOP

### Q157. What is a prototype?
An object from which another object can inherit properties and methods through the prototype chain.

### Q158. What is prototypal inheritance?
Objects can access properties and methods from their prototype. JavaScript searches the prototype chain when a property is not found directly.

### Q159. What is the prototype chain?
The linked sequence of prototype objects JavaScript searches for a property.

### Q160. What is a constructor function?
A function intended to create objects when called with `new`. `new` creates an object, links its prototype, calls the constructor with that object as `this`, and returns the object unless another object is explicitly returned.

### Q161. What are classes?
Class syntax provides a way to create objects and inheritance on top of JavaScript's prototype system.
```javascript
class Person {
  constructor(name) { this.name = name; }
  greet() { return `Hello ${this.name}`; }
}
```

### Q162. What do `extends` and `super` do?
`extends` creates a subclass. `super()` calls the parent constructor; `super.method()` calls a parent method.

### Q163. What are static methods?
Methods defined on the class itself, called using the class rather than an instance.

### Q164. What are getters and setters?
Accessor methods that let code read or assign a property-like value while running custom logic.

### Q165. What is encapsulation?
Grouping data and behaviour while controlling access to internal state. JavaScript supports private class fields using `#field`.

### Q166. What is `instanceof`?
It checks whether a constructor's prototype appears in an object's prototype chain. It is not a universal type check across all realms.

# 15. Errors, Debugging and Storage

### Q167. Name common JavaScript errors.
`SyntaxError`, `ReferenceError`, `TypeError`, `RangeError` and `URIError`.

### Q168. What is `try...catch...finally`?
`try` contains code that may throw; `catch` handles an error; `finally` runs after the try/catch flow regardless of success or failure in normal control flow.

### Q169. Difference between `throw` and `return`?
`return` exits a function with a value. `throw` raises an exception for an error handler to catch.

### Q170. How do you debug JavaScript?
Use breakpoints, the call stack, variable inspection, console, network panel and browser/IDE developer tools. Reproduce the issue and inspect values.

### Q171. What is `debugger`?
The `debugger;` statement requests a breakpoint when developer tools are open.

### Q172. What is localStorage?
A browser API for storing string key-value pairs, generally persisting across browser restarts until cleared.

### Q173. How do you store an object in localStorage?
Use `JSON.stringify()` when saving and `JSON.parse()` when reading.
```javascript
localStorage.setItem("user", JSON.stringify({ name: "Riya" }));
const user = JSON.parse(localStorage.getItem("user"));
```

### Q174. Is localStorage suitable for secrets?
No. JavaScript running on the same origin can read it, so XSS can expose stored data. Avoid storing sensitive secrets there.

# 16. Fetch, APIs and Browser Security

### Q175. What is an API?
An Application Programming Interface defines how software components communicate. A web API commonly exposes endpoints over HTTP.

### Q176. What is Fetch?
An API for HTTP requests. It returns a Promise resolving to a Response object.

### Q177. Does fetch reject for HTTP 404 or 500?
Usually no. Check `response.ok` or `response.status`; HTTP error responses still generally fulfill the fetch Promise.

### Q178. What is CORS?
Cross-Origin Resource Sharing is a browser mechanism that uses server response headers to permit specified origins to read cross-origin responses. Some requests require a preflight request.

### Q179. What is the same-origin policy?
A browser security rule restricting scripts from one origin from reading certain resources from another origin unless permitted, for example through CORS.

### Q180. What is XSS?
Cross-site scripting is a vulnerability where attacker-controlled script executes in a user's page. Avoid unsafe HTML injection and handle untrusted content safely.

### Q181. What is a Web Worker?
A worker runs JavaScript in a background thread separate from the main UI thread. It communicates using messages and cannot directly manipulate the DOM.

### Q182. What is a Service Worker?
A script running separately from a page that can intercept network requests, support offline experiences and enable features such as push notifications subject to browser support and permissions.

### Q183. What is AbortController?
It provides an AbortSignal to cancel supported asynchronous work, including fetch requests.

# 17. Performance and Common Patterns

### Q184. What is debouncing?
Debouncing delays a function until a specified quiet period passes without another call. Useful for searching after a user pauses typing.

### Q185. What is throttling?
Throttling limits how often a function can run during a period. Useful for scroll and resize handlers.

### Q186. Difference between debounce and throttle?
Debounce waits for activity to stop before running. Throttle limits the frequency of execution during continuous activity.

### Q187. What is lazy loading?
Loading resources only when needed, such as images as they approach the viewport.

### Q188. What is a memory leak?
Memory that is no longer needed remains reachable and cannot be reclaimed. Causes include retained references, forgotten listeners and unmanaged timers.

### Q189. How can JavaScript performance be improved?
Avoid unnecessary work and DOM updates, batch changes, debounce/throttle frequent handlers, lazy-load resources, profile first, and choose efficient algorithms and data structures.

### Q190. What is garbage collection?
Automatic memory management that reclaims memory for objects that are no longer reachable.

### Q191. What is `requestAnimationFrame()`?
A browser API that schedules a callback before the next repaint, commonly used for smooth visual animations.

# 18. Modules, Tooling and Runtime

### Q192. What is npm?
A package manager and registry commonly used with Node.js projects to install packages and run scripts.

### Q193. What is `package.json`?
A project manifest containing metadata, scripts, dependencies and configuration.

### Q194. Difference between dependencies and devDependencies?
`dependencies` are packages required by the application at runtime. `devDependencies` are used for development, testing, building or tooling.

### Q195. What is a bundler?
A tool that processes modules and assets for deployment. Examples include Vite, webpack and Rollup.

### Q196. What is transpilation?
Converting source code from one syntax or language version into another, often to support target environments.

### Q197. Browser JavaScript vs Node.js?
Both run JavaScript but provide different host APIs. Browsers provide DOM/window APIs; Node.js provides APIs such as filesystem and process access.

---

# Quick One-Line Revision

| Topic | Short answer |
|---|---|
| JavaScript | Dynamic language for interactive applications |
| DOM | Object-tree representation of a document |
| Hoisting | Declaration processing during scope setup |
| Closure | Function retaining access to its lexical scope |
| Callback | Function passed to another function |
| Promise | Represents eventual async result |
| Event loop | Coordinates queued callback execution |
| Call stack | Tracks active function calls (LIFO) |
| `this` | Value mainly determined by regular function call form |
| Prototype | Object used for inheritance |
| `map()` | Transforms every array item |
| `filter()` | Keeps items passing a test |
| `reduce()` | Combines items into one result |
| `===` | Strict equality without type coercion |
| `async` | Declares a function that returns a Promise |
| Event delegation | Parent listener handles child events |
| Debounce | Run after a quiet period |
| Throttle | Limit execution frequency |

# Fresher Interview Checklist

## Core
- [ ] `var`, `let`, `const`
- [ ] Scope, hoisting and TDZ
- [ ] Primitive and reference values
- [ ] `null`, `undefined`, `NaN`
- [ ] `==` vs `===`
- [ ] Truthy and falsy
- [ ] Strings, arrays and objects
- [ ] Functions, callbacks and arrow functions

## Intermediate
- [ ] Closures and lexical scope
- [ ] `this`, `call`, `apply`, `bind`
- [ ] Execution context and call stack
- [ ] Event loop and microtasks
- [ ] Promises and `async/await`
- [ ] DOM selection and manipulation
- [ ] Events, bubbling, capturing and delegation
- [ ] Fetch and error handling
- [ ] Prototypes, classes and modules

## How to answer
1. Start with a direct definition.
2. Explain the mechanism in simple words.
3. Give a small code example.
4. Mention one use case or limitation.
5. For output questions, trace the code step by step.

**Advice:** Do not memorize only definitions. Interviewers often ask follow-up questions and output-based problems to check whether you understand the behaviour.
