# JavaScript Complete Notes
## Beginner to Advanced — Simple Explanations with Examples

> This file covers core JavaScript language concepts. DOM and browser event manipulation are covered separately in `DOM-Complete-Notes.md`.

## How to study
- Read the definition first.
- Understand the example; type it and run it.
- Explain the concept aloud in your own words.
- Practise the revision checklist at the end.

## 1. Introduction to JavaScript

### What is JavaScript?
JavaScript is a programming language used to make websites interactive. It can respond to user actions, validate forms, update page content, communicate with APIs and build applications.

### JavaScript vs HTML vs CSS
- **HTML:** gives a webpage its structure.
- **CSS:** controls the appearance and layout.
- **JavaScript:** adds behaviour and interactivity.

### Where does JavaScript run?
- In browsers, using a JavaScript engine.
- Outside browsers using runtimes such as Node.js.

### What is ECMAScript?
ECMAScript is the standard specification that defines the core JavaScript language.

### Is JavaScript the same as Java?
No. They are separate languages with different designs and runtimes.

### Comments
```javascript
// Single-line comment

/*
  Multi-line comment
*/
```

## 2. Variables: var, let and const

A variable is a named place/binding used to refer to a value.

```javascript
var city = "Pune";
let age = 22;
const country = "India";
```

| Feature | `var` | `let` | `const` |
|---|---|---|---|
| Scope | Function/script | Block | Block |
| Reassign | Yes | Yes | No |
| Redeclare in same scope | Yes | No | No |
| Must initialize immediately | No | No | Yes |

**Remember:**
- Use `const` when you do not need to reassign the variable.
- Use `let` when the value needs to change.
- Avoid `var` in modern JavaScript unless you have a reason.

`const` prevents reassignment of the binding; it does not make an object or array deeply immutable.
```javascript
const user = { name: "Asha" };
user.name = "Riya"; // allowed
// user = {};       // TypeError: cannot reassign the binding
```

### Declaration, initialization and reassignment
```javascript
let marks;       // declaration
marks = 80;      // initialization
marks = 90;      // reassignment
```

## 3. Data Types

JavaScript has primitive and object types.

### Primitive types
1. String — text: `"hello"`
2. Number — numbers: `10`, `3.14`
3. Boolean — `true` or `false`
4. Undefined — a value has not been assigned
5. Null — intentional absence of a value
6. BigInt — large integers, e.g. `123n`
7. Symbol — unique identifier value

### Non-primitive type
Objects include ordinary objects, arrays, functions and dates.

### typeof
```javascript
console.log(typeof "hello"); // string
console.log(typeof 25);      // number
console.log(typeof true);    // boolean
console.log(typeof undefined); // undefined
console.log(typeof null);    // object (historical JavaScript quirk)
console.log(typeof []);      // object
```
To check null: `value === null`.

### null vs undefined
- `undefined`: value is missing or has not been assigned.
- `null`: programmer intentionally represents no value.

### NaN
`NaN` means “Not a Number”, but its type is `number`.
```javascript
console.log(Number("abc")); // NaN
console.log(Number.isNaN(NaN)); // true
```

## 4. Type Conversion and Coercion

**Type conversion** means changing a value from one type to another.

```javascript
Number("25");   // 25
String(25);     // "25"
Boolean(1);     // true
```

**Type coercion** is automatic conversion by JavaScript.
```javascript
console.log("5" + 2); // "52" (string concatenation)
console.log("5" - 2); // 3 (numeric conversion)
```

### == vs ===
- `==`: compares after possible type conversion.
- `===`: strict comparison without type conversion.
```javascript
5 == "5";  // true
5 === "5"; // false
```
Prefer `===` for predictable comparisons.

### Truthy and falsy values
Falsy values:
`false`, `0`, `-0`, `0n`, `""`, `null`, `undefined`, `NaN`.

Most other values are truthy, including `[]` and `{}`.
```javascript
Boolean("");  // false
Boolean("hi"); // true
Boolean([]);  // true
```

## 5. Operators

### Arithmetic
`+`, `-`, `*`, `/`, `%` (remainder), `**` (power).

### Comparison
`>`, `<`, `>=`, `<=`, `==`, `===`, `!=`, `!==`.

### Logical
- `&&` AND
- `||` OR
- `!` NOT

### Assignment
`=`, `+=`, `-=`, `*=`, `/=`.

### Increment
```javascript
let n = 5;
console.log(n++); // 5 (use old value, then increment)
console.log(++n); // 7 (increment, then use new value)
```

### Ternary operator
Short form of if/else:
```javascript
const result = age >= 18 ? "Adult" : "Minor";
```

### Nullish coalescing vs OR
```javascript
0 || 10; // 10: 0 is falsy
0 ?? 10; // 0: only null/undefined use fallback
```

### Optional chaining
```javascript
const city = user.address?.city;
```
If `address` is null or undefined, this returns `undefined` rather than throwing for that access.

## 6. Conditional Statements

```javascript
if (marks >= 80) {
  console.log("Good");
} else if (marks >= 40) {
  console.log("Pass");
} else {
  console.log("Try again");
}
```

### switch
```javascript
const day = 2;
switch (day) {
  case 1:
    console.log("Monday");
    break;
  case 2:
    console.log("Tuesday");
    break;
  default:
    console.log("Other day");
}
```
`break` exits the switch. Without it, execution may continue into the next case.

## 7. Loops

### for
```javascript
for (let i = 1; i <= 5; i++) {
  console.log(i);
}
```

### while
```javascript
let i = 1;
while (i <= 5) {
  console.log(i);
  i++;
}
```

### do...while
Runs at least once because the condition is checked after the body.
```javascript
let n = 1;
do {
  console.log(n);
  n++;
} while (n <= 3);
```

### break and continue
- `break`: exits the loop.
- `continue`: skips to the next iteration.

### for...of vs for...in
- `for...of`: values from iterables such as arrays and strings.
- `for...in`: enumerable property keys, often used with objects.

## 8. Strings

A string stores text and is immutable.

```javascript
const message = "Hello JavaScript";
```

### Template literals
Use backticks and `${}` to insert values:
```javascript
const name = "Anu";
console.log(`Hello, ${name}!`);
```

### Important string properties/methods

| Method/property | Purpose |
|---|---|
| `.length` | number of UTF-16 code units |
| `toUpperCase()` | uppercase |
| `toLowerCase()` | lowercase |
| `trim()` | remove whitespace at both ends |
| `includes()` | check whether text exists |
| `indexOf()` | first matching position, or -1 |
| `slice(start, end)` | extract part; supports negative indexes |
| `substring(start, end)` | extract part; negative indexes treated as 0 |
| `replace()` | replace first match for a string search |
| `replaceAll()` | replace all matches |
| `split()` | split string into an array |
| `startsWith()` | check starting text |
| `endsWith()` | check ending text |

```javascript
const text = "  JavaScript Notes  ";
console.log(text.trim());
console.log("hello".toUpperCase());
console.log("apple,banana".split(","));
```

## 9. Arrays

An array stores an ordered list of values. Index starts at `0`.

```javascript
const fruits = ["apple", "mango", "banana"];
console.log(fruits[0]); // apple
```

### Add and remove
| Method | Meaning |
|---|---|
| `push()` | add at end |
| `pop()` | remove from end |
| `unshift()` | add at beginning |
| `shift()` | remove from beginning |

### slice vs splice
- `slice(start, end)`: returns a shallow copy of a section; original array is unchanged.
- `splice(start, deleteCount, items...)`: changes the original array; can remove/insert/replace.

### Important array methods
```javascript
const numbers = [1, 2, 3, 4, 5];

numbers.map(n => n * 2);       // [2, 4, 6, 8, 10]
numbers.filter(n => n > 2);    // [3, 4, 5]
numbers.find(n => n > 2);      // 3
numbers.findIndex(n => n > 2); // 2
numbers.some(n => n > 4);      // true
numbers.every(n => n > 0);     // true
numbers.includes(3);           // true
numbers.reduce((sum, n) => sum + n, 0); // 15
```

- `map()`: transforms every item and returns a new array.
- `filter()`: keeps items that pass a condition.
- `forEach()`: runs a callback for each item; returns `undefined`.
- `reduce()`: combines values into one result.
- `find()`: returns first matching item.
- `some()`: true if at least one item passes.
- `every()`: true if all items pass.

### sort()
`sort()` changes the original array. For numeric order:
```javascript
const nums = [10, 2, 30];
nums.sort((a, b) => a - b); // [2, 10, 30]
```

### Destructuring
```javascript
const colors = ["red", "blue"];
const [first, second] = colors;
```

### Spread with arrays
```javascript
const copy = [...fruits];
const all = [...fruits, "orange"];
```
Spread creates a shallow copy.

### Remove duplicates
```javascript
const unique = [...new Set([1, 2, 2, 3])];
```

## 10. Objects

Objects store information as key-value properties.
```javascript
const student = {
  name: "Anu",
  age: 22,
  city: "Pune"
};
```

### Read properties
```javascript
student.name;       // dot notation
student["city"];   // bracket notation
```
Use bracket notation when the property name is dynamic or contains spaces/special characters.

### Add, update and delete
```javascript
student.course = "CSE"; // add
student.age = 23;       // update
delete student.city;    // delete
```

### Useful object methods
```javascript
Object.keys(student);   // property names
Object.values(student); // values
Object.entries(student);// [key, value] pairs
```

### Destructuring
```javascript
const { name, age } = student;
```

### Spread
```javascript
const updatedStudent = { ...student, age: 24 };
```
This is a shallow copy.

### Object.freeze and Object.seal
- `Object.freeze(obj)`: prevents adding/removing properties and changing existing own data properties.
- `Object.seal(obj)`: prevents adding/removing properties, but existing writable properties can change.
Both are shallow.

### Map and Set
- `Map`: key-value collection; keys can be any type; has `.size`.
- `Set`: stores unique values.
- `WeakMap`/`WeakSet`: weakly hold object keys/values and are not enumerable.

### JSON
```javascript
const jsonText = JSON.stringify(student);
const parsed = JSON.parse(jsonText);
```
JSON is a text format for exchanging data.

## 11. Functions

A function is reusable code that can accept inputs and return a result.

### Function declaration
```javascript
function add(a, b) {
  return a + b;
}
```

### Function expression
```javascript
const multiply = function (a, b) {
  return a * b;
};
```

### Arrow function
```javascript
const subtract = (a, b) => a - b;
```

### Parameters vs arguments
- Parameters: names in function definition.
- Arguments: actual values passed during a call.

### return vs console.log
- `return`: sends a result to the caller and ends the function.
- `console.log`: displays a value in the console; it does not automatically return it.

### Default parameters
```javascript
function greet(name = "Guest") {
  return `Hello ${name}`;
}
```

### Rest parameters
Collect remaining arguments into an array:
```javascript
function total(...values) {
  return values.reduce((sum, n) => sum + n, 0);
}
```

### Callback function
A function passed to another function so it can be called during that function's work or later.
```javascript
function processUser(name, callback) {
  callback(name);
}
processUser("Anu", name => console.log(name));
```

### Higher-order function
A function that accepts another function, returns a function, or both. `map()` and `filter()` are examples.

### IIFE
Immediately Invoked Function Expression:
```javascript
(function () {
  console.log("Runs immediately");
})();
```

### Recursion
A function calls itself. A base case must stop the recursion.
```javascript
function factorial(n) {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
}
```

### Pure function
Returns the same output for the same inputs and has no observable side effects.

### Currying
Transforms a multi-argument function into a sequence of functions:
```javascript
const add = a => b => a + b;
add(2)(3); // 5
```

## 12. Scope, Hoisting and TDZ

### Scope
Scope decides where a variable can be accessed.
- Global scope: accessible across the relevant script.
- Function scope: within a function.
- Block scope: within `{}` for `let` and `const`.

### Hoisting
Hoisting is the informal name for declaration processing during scope setup. JavaScript does not literally move the source code.

```javascript
console.log(a); // undefined
var a = 10;
```

`var` binding is initialized to `undefined`.

```javascript
// console.log(b); // ReferenceError (TDZ)
let b = 20;
```

`let` and `const` bindings exist but are uninitialized before the declaration is evaluated.

Function declarations can generally be called before their written position:
```javascript
sayHello();
function sayHello() {
  console.log("Hello");
}
```

### Temporal Dead Zone (TDZ)
The time from entering a scope until a `let` or `const` binding is initialized. Accessing it during this time throws `ReferenceError`.

### Shadowing
An inner-scope variable uses the same name as an outer variable and hides it inside the inner scope.

## 13. Closures

A closure is a function together with access to variables in its surrounding lexical scope, even after the outer function has finished.

```javascript
function createCounter() {
  let count = 0;

  return function () {
    count++;
    return count;
  };
}

const counter = createCounter();
console.log(counter()); // 1
console.log(counter()); // 2
```

**Step by step:**
1. `createCounter()` creates `count`.
2. It returns the inner function.
3. The outer function finishes.
4. The inner function still has access to `count`.
5. Each call updates the same preserved variable.

**Uses:** private state, counters, callbacks, event handlers, function factories and memoization.

## 14. `this`, call, apply and bind

For regular functions, `this` is mainly determined by how the function is called.

```javascript
const user = {
  name: "Anu",
  showName() {
    console.log(this.name);
  }
};
user.showName(); // Anu
```

Arrow functions do not create their own `this`; they use the surrounding lexical `this`.

### call, apply, bind
```javascript
function introduce(city) {
  console.log(`${this.name} from ${city}`);
}

const person = { name: "Anu" };

introduce.call(person, "Pune");       // invokes now
introduce.apply(person, ["Pune"]);    // invokes now
const bound = introduce.bind(person, "Pune"); // returns new function
bound();
```

- `call`: arguments separately.
- `apply`: arguments as an array/array-like value.
- `bind`: returns a new function with `this` fixed.

## 15. Execution Context and Call Stack

### Execution context
The environment in which JavaScript code is evaluated. It includes information such as lexical environments and the current `this` binding.

A simplified learning model:
1. Setup/creation phase: bindings and function declarations are prepared.
2. Execution phase: statements execute.

### Call stack
A Last-In, First-Out (LIFO) structure that tracks active function calls.
```javascript
function first() {
  second();
}
function second() {
  console.log("Inside second");
}
first();
```
`first()` is pushed, then `second()` is pushed. `second()` finishes and is popped, then `first()` finishes.

### Stack overflow
Happens when the call stack limit is exceeded, often due to uncontrolled recursion.

## 16. Synchronous and Asynchronous JavaScript

- Synchronous: statements run in sequence; the next waits for the current work to finish.
- Asynchronous: an operation completes later and JavaScript is notified using a callback, Promise or event.

### Event loop
The event loop coordinates when queued callbacks can run after synchronous work. Browser/runtime APIs handle certain operations outside the JavaScript call stack.

### Tasks and microtasks
- Tasks (often called macrotasks): timer callbacks and many event callbacks.
- Microtasks: Promise reactions and `queueMicrotask()` callbacks.
After current synchronous work, microtasks are generally processed before the next task.

```javascript
console.log("A");

setTimeout(() => console.log("B"), 0);

Promise.resolve().then(() => console.log("C"));

console.log("D");
```
Output:
```text
A
D
C
B
```

## 17. Promises and async/await

### Promise
An object representing the eventual success or failure of an asynchronous operation.
States:
1. Pending
2. Fulfilled
3. Rejected

```javascript
const task = new Promise((resolve, reject) => {
  const success = true;
  if (success) resolve("Done");
  else reject(new Error("Failed"));
});
```

### then, catch and finally
```javascript
task
  .then(result => console.log(result))
  .catch(error => console.error(error))
  .finally(() => console.log("Finished"));
```
- `then()`: handles fulfillment and chains results.
- `catch()`: handles rejection.
- `finally()`: runs after settlement regardless of outcome.

### Promise methods
- `Promise.all()`: fulfills when all fulfill; rejects if one rejects.
- `Promise.allSettled()`: waits for all to settle.
- `Promise.race()`: settles with the first settled input.
- `Promise.any()`: fulfills with the first fulfilled input; rejects with AggregateError if all reject.

### async/await
An `async` function always returns a Promise. `await` pauses that async function until the Promise settles.
```javascript
async function loadData() {
  try {
    const response = await fetch("/api/data");
    if (!response.ok) throw new Error("Request failed");
    const data = await response.json();
    return data;
  } catch (error) {
    console.error(error);
  }
}
```

### Fetch note
`fetch()` usually does not reject for HTTP 404/500. Check `response.ok` or `response.status`.

## 18. Prototypes, Classes and OOP

### Prototype
An object from which another object can inherit properties and methods.

### Prototype chain
When a property is not found directly on an object, JavaScript searches its prototype, then the next prototype, until it finds the property or reaches the end.

### Class
Class syntax provides a way to create objects and inheritance on top of prototypes.
```javascript
class Person {
  constructor(name) {
    this.name = name;
  }

  greet() {
    return `Hello ${this.name}`;
  }
}

const p = new Person("Anu");
console.log(p.greet());
```

### extends and super
- `extends`: creates a subclass.
- `super()`: calls the parent constructor.
- `super.method()`: calls a parent method.

### Static method
A method called on the class itself rather than on an instance.

### Encapsulation
Grouping data and behaviour and controlling access to internal state. JavaScript supports private class fields using `#`.
```javascript
class Account {
  #balance = 0;

  deposit(amount) {
    this.#balance += amount;
  }

  getBalance() {
    return this.#balance;
  }
}
```

## 19. Errors and Debugging

Common errors:
- `SyntaxError`: invalid syntax.
- `ReferenceError`: invalid or unavailable variable reference.
- `TypeError`: operation not valid for the value.
- `RangeError`: value outside allowed range.

### try/catch/finally
```javascript
try {
  // code that may throw
} catch (error) {
  console.error(error);
} finally {
  // runs after try/catch flow
}
```

- `throw`: raises an exception.
- `return`: exits a function with a value.
- `debugger;`: requests a breakpoint when developer tools are open.

## 20. Modules and npm basics

### Modules
Use `export` and `import` to split code into reusable files.
```javascript
// math.js
export const add = (a, b) => a + b;

// app.js
import { add } from "./math.js";
```

- Named exports: multiple named values can be exported.
- Default export: one default export per module.

### npm and package.json
- npm: package manager commonly used with Node.js.
- `package.json`: project manifest with scripts, dependencies and metadata.
- `dependencies`: packages needed at runtime.
- `devDependencies`: tools used for development/build/test.

## 21. Quick Revision Table

| Concept | Remember |
|---|---|
| `var` | Function-scoped; redeclare/reassign |
| `let` | Block-scoped; reassign, no same-scope redeclare |
| `const` | Block-scoped; no reassignment |
| Hoisting | Declaration processing during scope setup |
| TDZ | `let`/`const` inaccessible before initialization |
| Closure | Function remembers its lexical outer variables |
| Callback | Function passed to another function |
| Promise | Represents future async result |
| `async` | Function returns a Promise |
| `await` | Waits inside an async function |
| `map()` | Transform items into a new array |
| `filter()` | Keep matching items |
| `reduce()` | Combine items into one result |
| `===` | Strict equality |
| `this` | Depends on regular function call form |
| Prototype | Inheritance link between objects |

## 22. JavaScript Revision Checklist

- [ ] HTML, CSS and JavaScript roles
- [ ] `var`, `let`, `const`
- [ ] Primitive and object types
- [ ] `null`, `undefined`, `NaN`
- [ ] Type conversion and coercion
- [ ] `==` vs `===`
- [ ] Truthy/falsy values
- [ ] Operators and conditions
- [ ] Loops
- [ ] String methods
- [ ] Array methods: map/filter/reduce/find
- [ ] Objects, destructuring and spread
- [ ] Function declarations, expressions and arrows
- [ ] Callbacks and higher-order functions
- [ ] Scope, hoisting and TDZ
- [ ] Closures
- [ ] `this`, call, apply, bind
- [ ] Execution context and call stack
- [ ] Event loop and microtasks
- [ ] Promises and async/await
- [ ] Prototypes and classes
- [ ] Error handling and modules


---

# 23. Additional JavaScript Topics — Expanded Reference

These sections extend the core notes with commonly useful language features and interview topics. JavaScript is a large language, so no single document can literally contain every API and edge case; this section aims to make the learning notes broad and practical.

## 23.1 Number and Math

JavaScript's ordinary `Number` type uses IEEE 754 double-precision floating-point numbers.
```javascript
Number("42");          // 42
Number.isInteger(4);   // true
Number.isFinite(10);   // true
Number.isNaN(NaN);     // true
Number.isSafeInteger(10); // true
```

Useful `Math` methods:
```javascript
Math.round(4.6); // 5
Math.floor(4.9); // 4
Math.ceil(4.1);  // 5
Math.trunc(4.9); // 4
Math.max(2, 8);  // 8
Math.min(2, 8);  // 2
Math.abs(-5);    // 5
Math.sqrt(25);   // 5
Math.random();   // number from 0 up to (but not including) 1
```

Floating-point values can have precision surprises:
```javascript
0.1 + 0.2; // 0.30000000000000004
```
For money, use an appropriate decimal/money representation or store integer minor units (such as paise/cents) rather than relying on floating-point equality.

## 23.2 Dates and Time

Use `Date` to represent a point in time:
```javascript
const now = new Date();
const date = new Date("2026-11-15T10:00:00Z");

now.getFullYear();
now.getMonth(); // 0 = January, 11 = December
now.getDate();  // day of month
now.getDay();   // 0 = Sunday
now.getTime();  // milliseconds since Unix epoch
```

Important:
- `getMonth()` is zero-based.
- Local date/time methods use the host's local time zone.
- `toISOString()` returns a UTC representation.
- Parsing non-standard date strings can be inconsistent; prefer ISO-style strings.

For locale-aware display:
```javascript
new Intl.DateTimeFormat("en-IN", {
  dateStyle: "medium",
  timeStyle: "short"
}).format(new Date());
```

## 23.3 Regular Expressions (RegExp)

Regular expressions describe text patterns.
```javascript
const pattern = /^[A-Za-z]+$/;
pattern.test("Hello"); // true
```

Common symbols:
- `^` start of input
- `$` end of input
- `.` any character except line terminators (normally)
- `\d` digit; `\w` word character; `\s` whitespace
- `*` zero or more; `+` one or more; `?` zero or one
- `{n}` exactly n; `{n,m}` between n and m
- `[]` character set; `()` capture group
- `|` alternative

```javascript
const digits = "Room 204".match(/\d+/);
console.log(digits[0]); // "204"
```
Regular expressions are useful for pattern checks, but complex validation should also consider the actual business rules.

## 23.4 Deep Copy vs Shallow Copy

A shallow copy duplicates only the outer container. Nested objects remain shared.
```javascript
const original = { profile: { city: "Pune" } };
const shallow = { ...original };
shallow.profile.city = "Nagpur";
console.log(original.profile.city); // "Nagpur"
```

A deep copy duplicates nested data too, subject to the supported value types:
```javascript
const deep = structuredClone(original);
```
`structuredClone()` supports many built-in data types and circular references, but not every value (for example, functions). JSON stringify/parse is a limited technique and loses or changes some values such as `undefined`, functions, Symbols, BigInt and special object types.

## 23.5 Map, Set and Weak Collections — More Detail

### Map
Stores key-value pairs. Keys can be objects, functions or primitive values.
```javascript
const map = new Map();
map.set("name", "Anu");
map.set(1, "one");
map.get("name"); // "Anu"
map.has(1);       // true
map.delete(1);
map.size;
```
Useful methods: `set`, `get`, `has`, `delete`, `clear`, `keys`, `values`, `entries`, `forEach`.

### Set
Stores unique values:
```javascript
const set = new Set([1, 2, 2, 3]);
set.add(4);
set.has(2); // true
set.delete(1);
[...set]; // [2, 3, 4]
```

### WeakMap and WeakSet
- `WeakMap` keys must be objects (or non-registered Symbols where supported); entries do not keep object keys alive by themselves.
- `WeakSet` stores weakly held objects.
- They are not enumerable and do not expose a `.size`, because their contents can change as garbage collection occurs.

## 23.6 Symbols

A Symbol is a unique primitive value:
```javascript
const id = Symbol("id");
const user = { [id]: 123 };
console.log(user[id]); // 123
```
Two Symbols with the same description are still different:
```javascript
Symbol("x") === Symbol("x"); // false
```
Symbols are often used for unique property keys and language protocols.

## 23.7 Iterables and Iterators

An iterable provides a `[Symbol.iterator]()` method. Arrays and strings are iterable.
```javascript
for (const value of ["a", "b"]) {
  console.log(value);
}
```

An iterator has a `next()` method that returns an object like `{ value: ..., done: ... }`.
```javascript
const iterator = [10, 20][Symbol.iterator]();
iterator.next(); // { value: 10, done: false }
```

## 23.8 Generators

A generator function uses `function*` and `yield` to pause and resume:
```javascript
function* numbers() {
  yield 1;
  yield 2;
}
const gen = numbers();
gen.next(); // { value: 1, done: false }
gen.next(); // { value: 2, done: false }
gen.next(); // { value: undefined, done: true }
```
Generators produce iterators and can represent sequences lazily.

## 23.9 Proxy and Reflect

A `Proxy` wraps an object and can intercept operations:
```javascript
const user = { age: 20 };
const proxy = new Proxy(user, {
  get(target, property) {
    console.log("Reading", property);
    return Reflect.get(target, property);
  }
});
proxy.age; // logs property access, then 20
```
`Reflect` provides methods corresponding to many interceptable object operations. Proxies are advanced tools; use them only when their flexibility is needed.

## 23.10 Property Descriptors

Object properties have attributes such as `writable`, `enumerable` and `configurable`.
```javascript
const user = {};
Object.defineProperty(user, "id", {
  value: 10,
  writable: false,
  enumerable: true,
  configurable: false
});
```
`Object.getOwnPropertyDescriptor(user, "id")` reads the descriptor.

## 23.11 Getters and Setters

Getters and setters provide property-like access with custom logic:
```javascript
const person = {
  firstName: "Anu",
  lastName: "K",
  get fullName() {
    return `${this.firstName} ${this.lastName}`;
  },
  set fullName(value) {
    [this.firstName, this.lastName] = value.split(" ");
  }
};
```

## 23.12 More on Classes

- `constructor()` initializes a new instance.
- Instance methods are placed on the class prototype.
- `static` methods belong to the class itself.
- `extends` creates inheritance.
- `super()` calls the parent constructor.
- Private fields use `#field`.
- Getters/setters can provide controlled property access.

```javascript
class Animal {
  constructor(name) {
    this.name = name;
  }
  speak() {
    return `${this.name} makes a sound`;
  }
}

class Dog extends Animal {
  speak() {
    return `${this.name} barks`;
  }
}
```

## 23.13 Equality and Object Comparison

Primitive values are compared by value. Objects and arrays are compared by identity/reference:
```javascript
{} === {}; // false
const a = {};
const b = a;
a === b; // true
```
For structural comparison, use a deliberate comparison strategy suitable for the data. `JSON.stringify()` is not a universal deep-equality solution.

## 23.14 Strict Mode

`"use strict";` enables stricter parsing and runtime rules in scripts. ES modules and class bodies are strict automatically. Strict mode helps catch certain mistakes, such as assigning to an undeclared identifier.

## 23.15 Browser Runtime vs JavaScript Language

The JavaScript language defines syntax and core objects. The browser supplies host APIs such as DOM, timers, Fetch, storage and Web Workers. Node.js supplies a different set of host APIs. This distinction helps explain why `document` exists in a browser but not in a normal Node.js process.

## 23.16 Memory and Garbage Collection

JavaScript engines automatically reclaim memory that is no longer reachable. A memory leak can occur when code unintentionally keeps references alive, for example:
- Unremoved event listeners.
- Timers that keep running unnecessarily.
- Large objects kept in long-lived collections.
- Closures that retain data no longer needed.

Automatic garbage collection does not mean memory leaks are impossible.

## 23.17 More Browser and Web APIs to Recognize

These are host APIs rather than core language syntax:
- `fetch()` and `AbortController` for network requests and cancellation.
- `URL` and `URLSearchParams` for URL handling.
- `setTimeout()` and `setInterval()` for scheduling.
- `requestAnimationFrame()` for animation updates before repaint.
- Web Workers for background JavaScript execution without direct DOM access.
- Service Workers for request interception, offline support and related capabilities.
- `IntersectionObserver` for observing visibility/intersection.
- `MutationObserver` for observing DOM changes.
- `ResizeObserver` for observing element size changes.

## 23.18 Common Output Questions

### Q1. What is the output?
```javascript
console.log(typeof NaN);
```
Answer: `"number"`.

### Q2. What is the output?
```javascript
console.log([] == false);
console.log([] === false);
```
Answer: `true`, then `false`. Loose equality performs conversions; strict equality does not.

### Q3. What is the output?
```javascript
const a = [1, 2];
const b = a;
b.push(3);
console.log(a);
```
Answer: `[1, 2, 3]`. Both variables reference the same array.

### Q4. What is the output?
```javascript
console.log("A");
Promise.resolve().then(() => console.log("B"));
console.log("C");
```
Answer: A, C, B. Synchronous statements run before the Promise reaction microtask.

### Q5. What is the output?
```javascript
console.log(1 + "2" + 3);
console.log(1 + 2 + "3");
```
Answer: `"123"` and `"33"`. Evaluation proceeds left to right.

## 23.19 JavaScript Topics Checklist — Expanded

- [ ] Variables, declarations and assignment
- [ ] Primitive and object types
- [ ] Type conversion and coercion
- [ ] Equality, truthy/falsy and operators
- [ ] Conditions and all loop forms
- [ ] Strings, template literals and RegExp
- [ ] Arrays and iteration methods
- [ ] Objects, property access and descriptors
- [ ] Destructuring, spread and rest
- [ ] Functions, callbacks, recursion and currying
- [ ] Scope, hoisting, TDZ and closures
- [ ] `this`, call, apply and bind
- [ ] Execution context and call stack
- [ ] Event loop, tasks and microtasks
- [ ] Promises, async/await and Fetch
- [ ] Map, Set, WeakMap and WeakSet
- [ ] Symbols, iterators and generators
- [ ] Prototypes, classes and inheritance
- [ ] Getters, setters, Proxy and Reflect
- [ ] Errors, strict mode and debugging
- [ ] Modules, npm and package basics
- [ ] Date, Math, Intl and Number
- [ ] Shallow copy and deep copy
- [ ] Memory, garbage collection and performance
- [ ] Browser APIs and runtime differences
