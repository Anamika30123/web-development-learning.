# Recommended Study Order

1. JavaScript basics: variables, data types, operators, conditions, loops.
2. Functions, arrays, strings, objects, scope, closures, and hoisting.
3. Modern JavaScript and advanced concepts from the JavaScript notes.
4. Practise output-based questions and coding problems throughout.
5. DOM basics: selecting elements, reading/changing content and attributes, styles, creating and removing elements.
6. DOM events and event listeners; practise using the same callback reference with `removeEventListener`.
7. Expanded DOM topics: traversal, forms, event options, insertion/replacement, cloning, observers, accessibility, and performance.
8. Revise interview Q&A topic by topic.
